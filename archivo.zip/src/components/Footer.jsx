import React from "react";

const Footer = () => {
  return (
    <footer>
      <span>&copy; Alex Arroyo 2024</span>
    </footer>
  );
};

export default Footer;
